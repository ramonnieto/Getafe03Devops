# 🧪 Ejercicio DevOps: Crear un rol en Ansible para instalar Apache y PHP

## 🎯 Objetivo
Crear un rol llamado `apache_srv` que instale Apache y PHP en servidores Ubuntu y Rocky Linux usando buenas prácticas de Ansible.

---

## 🛠️ Pasos

### 1. Estructura
Este paquete contiene:
- Un rol completo (`roles/apache_srv`) con:
  - Tareas que usan módulos totalmente calificados (`ansible.builtin.dnf`, etc.)
  - Variables para diferenciar distribuciones
  - Handlers para reiniciar Apache
- Un `site.yml` que ejecuta el rol
- Un archivo `hosts.ini` para probar el playbook

---

### 2. Ejecutar

1. Descomprime el archivo:
   ```bash
   unzip apache_srv_exercise.zip
   cd apache_srv_exercise
   ```

2. Ejecuta el playbook:
   ```bash
   ansible-playbook -i hosts.ini site.yml
   ```

---

### 3. Resultado esperado

- Apache y PHP instalados en cada host según su sistema operativo.
- Apache reiniciado si hay cambios.

---

## ℹ️ Archivos clave

| Archivo | Descripción |
|--------|-------------|
| `site.yml` | Playbook principal que llama al rol |
| `hosts.ini` | Inventario con hosts de prueba |
| `roles/apache_srv/tasks/main.yml` | Lógica principal del rol |
| `roles/apache_srv/vars/main.yml` | Variables para paquetes por OS |
| `roles/apache_srv/handlers/main.yml` | Handler para reiniciar Apache |

---

## 🚀 ¡A practicar!
Este ejercicio está diseñado para usuarios de nivel inicial e intermedio. Puedes extenderlo con plantillas, archivos estáticos o pruebas.
